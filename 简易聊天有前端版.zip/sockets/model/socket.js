module.exports = function(io){
	var socketList = {};//获取socket连接列表
	var users = [];

	io.sockets.on('connection',function(socket){
		console.log('给我连接成功！不要出bug！');//啊啊啊啊啊啊啊啊，刚debug完数据库连接，又开始计网的连接
		//设置姓名、头像
		socket.on('join',(name,img) => {
			//console.log(socket);
			socket.name = name;//获取用户昵称
			socketList[name] = socket.id;//将用户昵称存入socketList中进行连接，并且为每个用户分配socket连接的id编号
			let user = {name:name,img:img,id:socket.id,tip:false};//获取用户的所有属性：昵称、头像、id，将消息提示设置为0
			users.push(user);//触发监听对象，收到数据后立即做出处理

			socket.broadcast.emit('welcome',name,users);//欢迎欢迎，热烈欢迎
			socket.emit('myself',name,users,socket.id);//介绍自己，将新的用户信息发送给所有其他客户端
		});
		//接收信息广播，socket.on和socket.emit的区别:服务端发送emit，客户端监听on
		socket.on('message',data => {
			//广播
			socket.broadcast.emit('sendMsg',data);//emit是会将消息发送给所有客户端，broadcast.emit是会将消息发送给除新建连接以外的所有其他客户端
		})
		//私聊
		socket.on('msg',data => {
			//console.log(data.tid);
			//广播
			socket.to(data.tid).emit('sMsg',data);
		})

		//用户离开
		socket.on('disconnecting',function(){
			if(socketList.hasOwnProperty(socket.name)){
				//用户退出
				delete socketList[socket.name];//从socketList中删除该socket连接，即用户退出
				for(var i=0;i<users.length;i++){
					if(users[i].name == socket.name){
						users.splice(i,1);
					}
				}
				//广播有用户退出
				socket.broadcast.emit('quit',socket.name,users);//昭告天下，退出了
			}
		})
	})
}