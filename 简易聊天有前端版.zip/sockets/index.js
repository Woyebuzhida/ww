const express = require('express')
const app = express()//使用express框架
const port = 3000//设置端口号为3000

var server = app.listen(8082)
var io = require('socket.io').listen(server);//这里socket的版本一定一定得降低，不然会报错没有require(xxxxx).listen的函数，啊啊啊啊啊救命，原来竟然是这个bug！
//引入socket.js
require('./model/socket.js')(io);


app.get('/', (req, res) => res.send('Hello World!'))//代码能力仅限于Hello World

app.listen(port, () => console.log(`Example app listening on port ${port}!`))//检验端口是否监听成功