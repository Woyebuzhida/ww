<template>
	<view class="content">
		<view class="title">Welcome to my channel!</view>
		<view class="head" @click="modify">
			<image :src="'../../static/images/'+nowimg+'.png'" mode="aspectFill" class="head-img"></image>
			<image src="../../static/down.png" mode="aspectFit" class="down"></image>
		</view>
		<input type="text" class="user" placeholder="先来取个名字吧" v-model="name" placeholder-style="color:#999;font-weight:400;font-size:30rpx"/>
		<view class="join" @tap="submit">加入</view>
		<view class="modify" :animation="animationData">
			<view class="modfiy-mian">
				<view v-for="(e,index) in img" :key="index" class="us-img" @tap="selected(index)">
					<image :src="'../../static/images/'+e.i+'.png'" mode="aspectFit"></image>	
					<view class="dd">
						<view class="ddd" :style="{opacity:e.x}"></view>
					</view>
				</view>
			</view>
		</view>
		<view class="bg" @tap="modify" :style="{display:bg}"></view>
		<view>
			<view class="haha">你将会从这个玩意儿中看到开发者各种夹带私货，比如从选择头像开始哈哈</view>
		</view>
		
	</view>
</template>

//第一次自己完全手搓前端代码，一不小心在view里写了“//”想加注释，我真是big clever
<script>
	export default {//export主要用于对外输出本模块变量的接口，一个文件就可以被理解为一个模块。将获取的值都导出
		data() {
			return {
				name:'',//用户昵称
				nowimg:'b',//用户进入页面时，页面所显示的头像，首先还是得可爱的阿狸和小小云
				animationData: {},//动画效果(两周前unity的记忆突然开始袭击我)
				bb:false,
				bg:'none',
				img:[
					{i:'1',x:1},//计
					{i:'2',x:0},//算
					{i:'3',x:0},//机
					{i:'4',x:0},//网
					{i:'5',x:0},//络
					{i:'6',x:0},
					{i:'7',x:0},
					{i:'8',x:0},
					{i:'9',x:0},
					{i:'10',x:0},
					{i:'11',x:0},
					{i:'12',x:0},
					{i:'13',x:0},
					{i:'14',x:0},
					{i:'15',x:0},
					{i:'16',x:0},
					{i:'17',x:0},
					{i:'a',x:0},
					{i:'b',x:0},
					{i:'c',x:0},
					{i:'d',x:0},//供选择的头像
				],
			}
		},
		onLoad() {

		},
		methods: {
			modify: function(){
				this.bb= !this.bb;
				if(this.bb){
					this.bg = 'block';
				}else{
					this.bg = 'none';
				}
				var animation = uni.createAnimation({
				  duration: 400,
				    timingFunction: 'ease',//ease：默认。动画以低速开始，然后加快，在结束前变慢
				})
				 this.animation = animation
				 if(this.bb){
				 	animation.bottom(0).step()
				 				 				  
				 }else{
				 	animation.bottom().step()		  
				 }				
				 this.animationData = animation.export()
			},
			selected: function(index){
				for(let i = 0;i<this.img.length;i++){
					this.img[i].x = 0;
				}
				this.img[index].x = 1;
				this.nowimg = this.img[index].i;
			},
			submit: function(){
				if(this.name.length>0){
					var mesg = {
						name:this.name,
						img: this.nowimg,
					}
					//console.log('发送消息时刻')
					uni.navigateTo({
					    url: '../chatroom/chatroom?name='+this.name+'&img='+this.nowimg,
					});
					//this.socket.emit('login',mesg);
				}
			},
		}
	}
</script>
//下面全是样式，重复无聊的工作
<style lang="scss">
	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		padding-top: 200rpx;
	}

	.title {
		font-size:36rpx;
		font-weight:600;
		color:rgba(126, 186, 186, 1.0);
		line-height:50rpx;
		padding-bottom: 116rpx;
	}
	.haha{
		font-size:18rpx;
		font-weight:600;
		color:rgba(164, 166, 153, 1.0);
		line-height:0rpx;
		padding-top: 50rpx;
	}
	.head{
		width: 144rpx;
		height: 144rpx;
		position: relative;
		.head-img{
			margin-top: -20rpx;
			width: 144rpx;
			height: 144rpx;
			border-radius: 50%;
		}
		.down{
			position: absolute;
			opacity: 0.6;
			right: -48rpx;
			top: 48rpx;
			width: 48rpx;
			height: 48rpx;
		}
	}
	.user{
		margin-top: 54rpx;
		padding: 0 24rpx;
		width:440rpx;
		height:96rpx;
		background:rgba(242,242,242,1);
		border-radius:24rpx;
		text-align: center;
		font-size: 36rpx;
		font-weight:600;
		color:rgba(25,29,35,1);
	}
	.join{
		margin-top: 180rpx;
		width:200rpx;
		height:200rpx;
		background:rgba(158, 215, 217, 1.0);
		box-shadow:0px 36rpx 68rpx -8rpx rgba(150, 204, 206, 1.0);
		border-radius: 50%;
		font-size:28rpx;
		font-weight:600;
		text-align: center;
		line-height: 200rpx;
		color:rgba(115, 116, 96, 1.0);
	}
	.modify{
		position: fixed;
		left: 0;
		bottom:-800rpx;
		width: 100%;
		height: 800rpx;
		z-index: 1000;
		background: #fff;
		border-radius:48rpx 48rpx 0px 0px;
	}
	.modfiy-mian{
		padding: 80rpx 36rpx;
		flex-direction: row;
		display: flex;
		flex-wrap:wrap;
		.us-img{
			flex: auto;
			width: 20%;
			text-align: center;
			image{
				width:80rpx;
				height:80rpx;
				border-radius:18rpx;
			}
			.ddd{
				display: inline-block;
				justify-content:center;
				margin-bottom: 40rpx;
				width: 16rpx;
				height: 16rpx;
				background:rgba(255,131,60,1);
				border-radius: 50%;
			}
		}
	}
	.bg{
		width: 100%;
		height: 100%;
		position: fixed;
		top: 0;
		left: 0;
		background-color: rgba(0,0,0,0.4);
	}
</style>
