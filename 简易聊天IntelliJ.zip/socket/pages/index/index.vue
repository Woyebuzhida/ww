<template>
	<view class="content">
		<view class = "main">
			<view v-for = "e in arr">{{e}}</view>
		</view>
		<view class = "foot">
			<input type = "text" class = "cont" v-model = "cont">
			<button @tap = "send">Send</button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				cont: '',
				arr:['啊啊啊啊啊熬过期末周，我又可以了！！','早点放假早点放假早点放假','计网怎么这么难啊，呜呜呜呜',
				'谁懂手搓前端代码的快乐？？！！','不要靠近前端，会变的不幸'],
			}
		},
		onLoad() {

		},
		methods: {
			send: function(){
				this.arr.push(this.cont)
				//发送
				let aa = this.cont//声明一个变量放入输入的值
				this.socket.emit('message',aa);
			}
		}	
	}
</script>

<style lang = "scss">
	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}

	.title {
		font-size: 36rpx;
		color: #8f8f94;
	}
	
	.foot{
		position: fixed;
		width:100%;
		bottom:0;
		.cont{
			width: 100%;
			height: 80rpx;
			background-color: #e2e2e2;
		}
	}
</style>
