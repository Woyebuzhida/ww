#include "WinSock2.h"    // winsock2.h是套接字接口。
#include "process.h"    //process.h 是包含用于和宏指令的作用声明与螺纹和过程一起使用的C标头文件。
#include "stdio.h"     //被包含的文件通常是由系统提供的，其扩展名为.h,而stdio为standard input output的缩写，意为“标准输入输出”
#include "stdlib.h"    //stdlib 头文件里包含了C语言的一些函数,该文件包含了的C语言标准库函数的定义
#include "conio.h"     //将conio.h包含入你的程序，使你可以引用其中声明的函数。conio.h不是C标准库中的头文件。
#pragma comment(lib,"ws2_32.lib")     // ws2_32.lib是套接字实现。
#define RECV_OVER 1
#define RECV_YET 0
char userName[20] = { 0 };
int Status = RECV_YET;
unsigned __stdcall ThreadRecv(void* param);  //接受数据的线程
unsigned __stdcall ThreadSend(void* param);  //发送数据的线程
int main(void)
{
	WSADATA wsaData = { 0 };      
  SOCKET ClientSocket = INVALID_SOCKET;   //客户端套接字
  sockaddr_in ServerAddr = { 0 };     //服务端地址，SOCKADDR_IN为结构体，可以小写
 unsigned short SERVERPORT = 6666; 
//初始化套接字

 WSADATA data;
  int ret=WSAStartup(MAKEWORD(2,2),&data);   //WSAStartup函数的返回值是0表示成功 
  if (SOCKET_ERROR==ret)        
  {
	  printf("WSAStartup 启动错误!\n");               
    return -1;
  }
  
  //创建套接字
  ClientSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
  if ( INVALID_SOCKET == ClientSocket)
  {
    
	  printf("socket创建失败！\n");
	  WSACleanup();
      return -1;
  }
  //输入服务器IP
  printf("请输入服务器的IP:");
  char IP[32] = { 0 };
  gets_s(IP,31);
  //设置服务器地址
  ServerAddr.sin_family = AF_INET;  
  ServerAddr.sin_port = htons(SERVERPORT);           //服务器端口
  ServerAddr.sin_addr.S_un.S_addr = inet_addr(IP);   //服务器地址
  printf("正在努力连接服务器.....\n");
  //连接服务器
  ret=connect(ClientSocket,(sockaddr*)&ServerAddr,sizeof(ServerAddr));
  if ( SOCKET_ERROR ==ret)   
  {
	  printf("connect连接服务器失败！\n");
	  closesocket(ClientSocket);
      WSACleanup();
      return -1;
  }
  printf("成功连上服务器 IP:%s Port:%d\n",IP,htons(ServerAddr.sin_port));
  printf("欢迎登录66微聊聊天室！\n");
  printf("请输入你的名字: ");
  gets_s(userName,20);
  send(ClientSocket, userName, sizeof(userName), 0);
  printf("\n\n");
  _beginthreadex(NULL, 0, ThreadRecv, &ClientSocket, 0, NULL); //启动接收和发送消息线程
  _beginthreadex(NULL, 0, ThreadSend, &ClientSocket, 0, NULL);
  for (int k = 0;k < 1000;k++)         // 让主线程休眠，不让它关闭TCP连接
  {
	  
	  Sleep(10000000);
  }
  closesocket(ClientSocket);
  WSACleanup();
  return 0;
}

unsigned __stdcall ThreadRecv(void* param)
{
	char buf[512] = { 0 };
  while (1)
  {
    int ret = recv(*(SOCKET*)param, buf, sizeof(buf), 0);   //先强行转化为SOCKET*,不然void*直接引用会出错
    if (SOCKET_ERROR == ret)
    {
      Sleep(500);          //将进程挂起一段时间，即停下来0.5s再继续
      continue;
    }
    if (strlen(buf) != 0)    //判断缓冲区是不是有数据，有就打印出来！
    {
      printf("%s\n", buf);
      Status = RECV_OVER;     //把状态设为已接收
    }
    else
      Sleep(100);  
 
 
  }
  return 0;
}

unsigned __stdcall ThreadSend(void* param)
{
	char buf[512] = { 0 };
  int ret = 0;
  while (1)
  {
   int c = getch();                       //在头文件conio.h有定义，此函数是一个不回显函数，当用户按下某个字符时，此函数自动读取，无需按回车
    if(c == 72 || c == 0 || c == 68)       //遇到这几个值getch就会自动跳过
      continue;        
    printf("%s: ", userName);
    gets_s(buf,511);                       //此函数在stdio.h中定义，第二参数就是允许输入长度，留一位补零，否则溢出
    ret = send(*(SOCKET*)param, buf, sizeof(buf), 0);
    if (ret == SOCKET_ERROR)
      if (ret == SOCKET_ERROR)
	{
		return 1;
	}
	if(strcmp(buf,"bye") == 0||strcmp(buf,"再见")==0) 
	{
		printf("您已退出聊天室！\n");
		break;
	}
  }
  return 0;
}