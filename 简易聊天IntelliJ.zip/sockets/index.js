const express =  require('express')
const app = express()
const port = 3000

//运行一个用做即时通讯的端口
var server = app.listen(8082)
var io = require('socket.io').listen(server);

//socket.io的使用
io.on('connection', (socket) => {
	//console.log('给我连接成功，不许有bug！！');

	//接收信息
	socket.on('message',(data) =>{
		console.log(data);

		socket.broadcast.emit('gbmsg',data);
	})
});

//用express建立后端server服务
app.get('/', (req, res) => res.send('Hello World!'))

app.listen(port, () => console.log(`给我连接成功，不许有bug！！Example app listening on port ${port}!`))