package mainmethod;

public class main {
    public static void main(String[] args)
    {
        Thread thread1 = new Thread(new chat());//使用Thread的构造方法public Thread(Runnable target)创建,这个需要传入一个实现Runnable接口的子类
        thread1.start();//执行线程
    }
}

