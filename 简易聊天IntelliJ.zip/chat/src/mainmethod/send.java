package mainmethod;

import MyFrame.MyFrame;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public class send extends Thread{
    String Name;//名称
    MyFrame myframe;//界面格式
    InetAddress IP1;//目的IP
    int Port1;//目的端口
    int Port2;//接收端口


    public send(InetAddress ip1,int port1,String name,int port2, MyFrame myframe) {
        this.myframe=myframe;//继承界面
        IP1 = ip1;//设置目的IP
        Port1 = port1;//设置目的端口
        Name=name;//设置名称
        Port2 = port2;//设置发送端口

    }

    @Override
    //线程中的run()方法
    public void run() {
        try
        {
            //DatagramSocket类是发送和接收数据报的插座，遵循UDP协议
            DatagramSocket socket =new DatagramSocket(Port2);//构建数据报套接字，绑定到指定端口
            System.out.println("Succeed");//连接成功
            while (true)
            {
                while (myframe.Intext==null)
                {//输入不为空时
                    Thread.currentThread().sleep(20);//获取对象后调用sleep静态方法
                }
                String msg =Name+":"+myframe.Intext;//设置消息格式为：“名称：消息”
                //DatagramPacket类表示数据报包，数据报包用来实现无连接包投递服务
                //构造DatagramPacket，用来将长度为length，偏移量为0的包发送到IP1上的Port1端口
                DatagramPacket packet = new DatagramPacket(msg.getBytes(), 0, msg.getBytes().length, IP1, Port1);
                socket.send(packet);//发送packet
                //setText实现字符串+数值作为参数
                myframe.text.setText(myframe.text.getText()+Name+":"+myframe.Intext+"\n");
                myframe.Intext=null;//发送完消息后，清空消息框

                if(new String(packet.getData(),0,packet.getLength()).equals("bye"))//如果用户输入bye就结束进程
                {
                    break;
                }
            }
            socket.close();//关闭套接字连接
        }
        //捕捉异常，将异常信息打印在控制台
        catch (SocketException e)//具有输入的IP地址的主机无法找到或找不到端口进行监听
        {
            e.printStackTrace();//打印异常
        }
        catch (IOException e)//使用流、文件和目录访问信息时引发的异常
        {
            e.printStackTrace();
        }
        catch (InterruptedException e)//党组色方法收到中断请求的时候会抛出InterruptedException异常
        {
            e.printStackTrace();
        }
    }
}

