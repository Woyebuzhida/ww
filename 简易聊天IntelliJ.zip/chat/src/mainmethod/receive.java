package mainmethod;

import MyFrame.MyFrame;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

public class receive extends Thread{
    int port;//声明port才储存端口号
    MyFrame myframe;//界面格式

    public receive(int port,MyFrame myframe) {
        this.port = port;//继承port
        this.myframe=myframe;//继承格式
    }

    @Override//Override注解，用来指定方法重写，只能修饰方法，不能修饰其他元素，强制一个子类必须重写父类或者实现接口
    public void run() {
        try
        {
            //DatagramSocket类是发送和接收数据报的插座，遵循UDP协议
            DatagramSocket socket=new DatagramSocket(port);
            while (true)
            {
                byte[] buffer = new byte[1024];//定义一个字节数组，相当于缓存
                //构造DatagramPacket，用来接收长度为length的包，在缓冲区指定偏移量为0
                DatagramPacket packet = new DatagramPacket(buffer, 0, buffer.length);
                socket.receive(packet);//接收packet
                //接收的消息是bue时，结束进程
                if (new String(packet.getData(), 0, packet.getLength()).equals("bye"))
                {
                    break;
                }
                String msg=new String(packet.getData(), 0, packet.getLength());//UDP消息发送
                myframe.text.setText(myframe.text.getText()+msg+"\n");//实现字符串+数值的显示
                System.out.println(msg);//打印出message

            }
            socket.close();
        }
        catch (SocketException e)//具有输入的IP地址的主机无法找到或找不到端口进行监听
        {
            e.printStackTrace();//打印异常
        }
        catch (IOException e)//使用流、文件和目录访问信息时引发的异常
        {
            e.printStackTrace();
        }
        //catch (InterruptedException e)//党组色方法收到中断请求的时候会抛出InterruptedException异常
        //{
        //   e.printStackTrace();
        //}
    }
}
