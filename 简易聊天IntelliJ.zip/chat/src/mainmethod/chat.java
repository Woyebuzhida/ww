package mainmethod;

import MyFrame.MyFrame;
public class chat implements Runnable{
    //implements Runnable——java多线程实现方法
    public chat() {
    }

    @Override
    public void run() {
        MyFrame myFrame = new MyFrame();
    }
}