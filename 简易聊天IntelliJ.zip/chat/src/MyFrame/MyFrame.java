package MyFrame;

import mainmethod.receive;
import mainmethod.send;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.InetAddress;
import java.net.UnknownHostException;

//设置格式，类似于搭前端，应该就没什么好注释了的吧
public class MyFrame extends JFrame {
    public InetAddress ip1;//设置目的IP地址
    public int port1;//设置目的端口号
    public int port2;//发送端口号
    public int port3;//接收端口号
    public String Intext;//字符串
    public TextArea text;//文本
    public String name;//昵称
    //设置JUI
    private JTextField t1;//存储目的IP
    private JTextField t2;//目的的端口
    private JTextField t3;//发送端口
    private JTextField t4;//接受端口
    private JTextField A;//文本框
    private JButton B;//进入
    private JButton C;//名称
    private JButton D;//连接

    public MyFrame(){
        Container container = getContentPane();
        container.setBackground(Color.cyan);
        //container.setVisible(false);

        setTitle("Let's chat!");
        setVisible(true);
        setBounds(570,135,400,600);//设置窗口的大小和位置
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        JPanel panel1=new JPanel(new GridLayout(2,1));//GridLayout网格布局一行两列
        //panel1.setVisible(false);
        panel1.setSize(10,20);
        panel1.setLocation(10,20);
        JPanel panel2=new JPanel();
        JPanel panel3=new JPanel(new GridLayout(1,2));
        JPanel panel4=new JPanel(new FlowLayout());
        panel3.add(panel4);
        panel3.add(new JLabel(" ",SwingConstants.CENTER));
        container.add(panel1,BorderLayout.NORTH);
        container.add(panel2,BorderLayout.CENTER);
        container.add(panel3,BorderLayout.SOUTH);

        D=new JButton("Connection");
        D.setBackground(Color.ORANGE);
        D.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new ConnectionJDialog();
            }
        });
        C=new JButton("Hi,take a name");
        C.setBackground(Color.ORANGE);
        C.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new SetNameConnection();
            }
        });
        text =new TextArea(30,35);
        text.setBackground(Color.pink);
        A=new JTextField(18);
        //JPanel panel5 = new JPanel(new GridLayout(1,1);
        B=new JButton("Send");
        B.setBounds(200,300,20,40);
        setBounds(200,200,400,400);
        panel1.add(D);
        panel1.add(C);
        panel2.add(text);
        panel4.add(A);
        panel4.add(B);
        B.addActionListener(new action_enter());
    }
    private class action_enter implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            Intext=A.getText();
            A.setText("");
        }
    }
    private class SetNameConnection extends JDialog{
        public SetNameConnection() {
            pack();
            setVisible(true);
            setTitle("Name");
            //setBackground(Color.pink);
            setBounds(500,200,400,70);
            setBackground(Color.cyan);
            Container container = getContentPane();
            container.setLayout(new FlowLayout());
            setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);

            JLabel jLabel = new JLabel("Hi, take your name");
            jLabel.setBackground(Color.pink);
            JTextField username = new JTextField(8);
            username.setText(name);
            JButton button = new JButton("Sure?");
            button.setBackground(Color.pink);
            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    name=username.getText();
                    System.out.println(name);
                }
            });
            container.add(jLabel);
            container.add(username);
            container.add(button);
        }
    }
    private class ConnectionJDialog extends JDialog {
        public ConnectionJDialog() {
            setVisible(true);
            setTitle("Connection");
            setBackground(Color.pink);
            setBounds(200,200,400,200);
            Container container = getContentPane();
            container.setLayout(new GridLayout(5,2));
            setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);

            t1=new JTextField();
            t1.setText("192.168.136.1");
            t1.setBackground(Color.cyan);
            t2=new JTextField();
            t2.setText(String.valueOf(port1));
            t2.setBackground(Color.CYAN);
            t3=new JTextField();
            t3.setText(String.valueOf(port2));
            t3.setBackground(Color.cyan);
            t4=new JTextField();
            t4.setText(String.valueOf(port3));
            t4.setBackground(Color.CYAN);
            JButton ok = new JButton("Make Connection");
            ok.setBackground(Color.pink);
            ok.addActionListener(new action_ok());

            JLabel label1=new JLabel("TO_IP:");
            //label1.setFont(Font.createFont());
            JLabel label2=new JLabel("TO_PORT:");
            //label2.setBackground(Color.pink);
            JLabel label3=new JLabel("SEND_PORT:");
            //label3.setBackground(Color.pink);
            JLabel label4=new JLabel("RECEIVE_PORT");
            //label4.setBackground(Color.pink);
            JLabel label5 = new JLabel("Are you sure?");
            //label5.setBackground(Color.pink);

            container.add(label1);
            container.add(t1);
            container.add(label2);
            container.add(t2);
            container.add(label3);
            container.add(t3);
            container.add(label4);
            container.add(t4);
            container.add(ok);

        }
        private class action_ok implements ActionListener {

            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    ip1 = InetAddress.getByName(t1.getText());
                    port1=Integer.parseInt(t2.getText());
                    port2=Integer.parseInt(t3.getText());
                    port3=Integer.parseInt(t4.getText());
                    send thread1 = new send(ip1,port1,name,port2,MyFrame.this);
                    thread1.start();
                    receive thread2 = new receive(port3,MyFrame.this);
                    thread2.start();
                } catch (UnknownHostException unknownHostException) {
                    unknownHostException.printStackTrace();
                }
            }
        }
    }
}


